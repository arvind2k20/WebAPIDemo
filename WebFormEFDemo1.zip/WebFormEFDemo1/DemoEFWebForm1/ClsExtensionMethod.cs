﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DemoEFWebForm1
{
    public class ClsExtensionMethod
    {
        public static bool IsVege(Product p)
        {
            return p.ProductName.Contains("vegetable");
        }

        static void Main(string[] args)
        {


            List<Product> products = new List<Product>()
            {
                new Product { 
                    ProductID = 1, 
                    ProductName = "first candy", 
                    UnitPrice = (decimal)10.0 },
                new Product { 
                    ProductID = 2, 
                    ProductName = "second candy", 
                    UnitPrice = (decimal)35.0 },
                new Product { 
                    ProductID = 3, 
                    ProductName = "first vegetable", 
                    UnitPrice = (decimal)6.0 },
                new Product { 
                    ProductID = 4, 
                    ProductName = "second vegetable", 
                    UnitPrice = (decimal)15.0 },
                new Product { 
                    ProductID = 5, 
                    ProductName = "another product", 
                    UnitPrice = (decimal)55.0 }
            };



            //List<Product> products = new List<Product>();

            var veges1 = products.Get(IsVege);

            Console.WriteLine("\nThere are {0} vegetables:", veges1.Count());

            foreach (Product p in veges1)
            {
                Console.WriteLine("Product ID: {0} Product name: {1}",
                        p.ProductID, p.ProductName);
            }



            var veges4 = products.Get(p => p.ProductName.Contains("vegetable"));
            var veges5 = products.Get((Product p) => p.ProductName.Contains("vegetable"));
            var candies = products.Get(p => p.ProductName.Contains("candy"));

            var veges6 = products.Where(p => p.ProductName.Contains("vegetable"));


            //LINQ Query syntax to fetch records
            var veges7 = from p in products
                         where p.ProductName.Contains("vegetable")
                         select p;




            var candyOrVeges = from p in products
                               where p.ProductName.Contains("candy")
                                     || p.ProductName.Contains("vegetable")
                               orderby p.UnitPrice descending, p.ProductID
                               select new { p.ProductName, p.UnitPrice };


            //IEnumerable<Product> = ?
            //Method syntax to get the list
            var candyorVeges2 = products.Where(p => p.ProductName.Contains("candy")
             || p.ProductName.Contains("vegetable")).OrderByDescending(p => p.UnitPrice).ThenBy(p => p.ProductID)
             .Select(p => new { p.ProductName, p.UnitPrice });


            foreach (var p in candyOrVeges)
            {
                Console.WriteLine("{0} {1}", p.ProductName, p.UnitPrice);
            }


        }
    }


    public sealed class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public decimal UnitPrice { get; set; }

       
        
    }
  
    
    public static class MyExtensions
    {
        public static bool IsCandy(this Product p)
        {
            if (p.ProductName.IndexOf("candy") >= 0)
                return true;
            else
                return false;
        }


        public static IEnumerable<T> Get<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            foreach (T item in source)
            {
                if (predicate(item))
                    yield return item;
            }
        }


        

    }

    

}






/* 
 
 Lambda expressions
With the C# 3.0 new Extension Method feature, and the C# 2.0 new anonymous method (or inline method) feature, Visual Studio has introduced a new expression called lambda expression.

Lambda expression is actually a syntax change for anonymous methods. It is just a new way of writing anonymous methods. Next, let's see what a lambda expression is step by step.

First, in C# 3.0, there is a new generic delegate type, Func<A,R>, which presents a function taking an argument of type A, and returns a value of type R:

Hide   Copy Code
delegate R Func<A,R> (A Arg);
In fact, there are several overloaded versions of Func, of which Func<A,R> is one.

Now, we will use this new generic delegate type to define an extension:

Hide   Copy Code
public static IEnumerable<T> Get<T>(this IEnumerable<T> source, Func<T, bool> predicate)
{
    foreach (T item in source)
    {
        if (predicate(item))
            yield return item;
    }
}
This extension method will apply to an object that extends the IEnumerable interface, and has one parameter of type Func, which you can think of as a pointer to a function. This parameter function is the predicate to specify the criteria for the selection. This method will return a list of objects that match the predicate criteria.

Now we can create a new function as the predicate:

Hide   Copy Code
public static bool IsVege(Product p)
{
    return p.ProductName.Contains("vegetable");
}
Then we can use the Extension Method Get to retrieve all of the vegetable products, like this:

Hide   Copy Code
var veges1 = products.Get(IsVege);
In previous sections, we have created a products list, with five products, of which two are vegetables. So veges1 is actually of the IEnumerable<Product> type, and should contain two products. We can write the following test statements to print out the results:

Hide   Copy Code
Console.WriteLine("\nThere are {0} vegetables:", veges1.Count());
foreach (Product p in veges1)
{
    Console.WriteLine("Product ID: {0} Product name: {1}", 
            p.ProductID, p.ProductName);
}
The output will be:

IntroducingLINQ/Pic3.png

Or, we can first create a new variable of type Func, assign the function pointer of IsVege to this new variable, and then pass this new variable to the Get method, like this:

Hide   Copy Code
Func<Product, bool> predicate = IsVege;
var veges2 = products.Get(predicate);
The variable veges2 will contain the same products as veges1.

Now, let us use the C# 2.0 anonymous method to rewrite the above statement, which will now become:

Hide   Copy Code
var veges3 = products.Get(
    delegate (Product p)
    {
        return p.ProductName.Contains("vegetable");
    }
);
At this time, we put the body of the predicate method IsVege inside the Extension Method call, with the keyword delegate. So, in order to get the vegetables from the products list, we don't have to define a specific predicate method. We can specify the criteria on the spot, when we need it.

The lambda expression comes into play right after the above step. In C# 3.0, with lambda expression, we can actually write the following one line statement to retrieve all of the vegetables from the products list:

Hide   Copy Code
var veges4 = products.Get(p => p.ProductName.Contains("vegetable"));
In the above statement, the parameter of the method Get is a lambda expression. The first p is the parameter of the lambda expression, just like the parameter p in the anonymous method when we get veges3. This parameter is implicitly typed and, in this case, is of type Product, because this expression is applied to a Products object, which contains a list of Product objects. This parameter can also be explicitly typed, like this:

Hide   Copy Code
var veges5 = products.Get((Product p) => p.ProductName.Contains("vegetable"));
The parameter is followed by the => token, and then followed by an expression or a statement block, which will be the predicate.

So, now we can easily write the following statement to get all of the candy products:

Hide   Copy Code
var candies = products.Get(p => p.ProductName.Contains("candy"));
At compile time, all lambda expressions are translated into anonymous methods according to the lambda expression conversion rules. So again, this feature is only a Visual Studio feature. We don't need any special .NET runtime library or instructions to run an assembly containing lambda expressions.

In short, lambda expressions are just another way of writing anonymous methods in a more concise, functional syntax.
 
 */