﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoEFWebForm1
{
    public partial class TestLINQ : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            List<int> list = new List<int>() { 1, 2, 3, 4, 5, 6, 100 };

            List<int> list1 = new List<int>() { 0,25,4,4,5,7,8,6,0,8};

            //Traditional method without LINQ
            //List<int> list3 = new List<int>();
            //foreach (var num in list)
            //{
            //    if (num % 2 == 0)
            //    { 
            //        list1.Add(num);
            //       lbl.Text = lbl.Text + " " + num.ToString();
            //    }
            //}


            var list4 = from number in list
                        where number % 2 == 0
                        select number;
            lbl.Text = list4.Average().ToString();


            //Object Initializer
            Product product = new Product
            {
                ProductID = 1,
                ProductName = "first candy",
                UnitPrice = (decimal)100.0
            };

            product.ProductID = 2;

            //Collection Initializer
            List<Product> products = new List<Product>()
            {
                new Product { 
                    ProductID = 1, 
                    ProductName = "first candy", 
                    UnitPrice = (decimal)10.0 },
                new Product { 
                    ProductID = 2, 
                    ProductName = "second candy", 
                    UnitPrice = (decimal)35.0 },
                new Product { 
                    ProductID = 3, 
                    ProductName = "first vegetable", 
                    UnitPrice = (decimal)6.0 },
                new Product { 
                    ProductID = 4, 
                    ProductName = "second vegetable", 
                    UnitPrice = (decimal)15.0 },
                new Product { 
                    ProductID = 5, 
                    ProductName = "another product", 
                    UnitPrice = (decimal)55.0 }
            };

            //products.Add(product);


            


        }

       

       



    }

  


       
}