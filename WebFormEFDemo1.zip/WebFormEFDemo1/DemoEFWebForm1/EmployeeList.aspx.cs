﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoEFWebForm1
{
    public partial class EmployeeList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack)
            {


                var context = new EmployeesEntities();

                var deptlist = (from dept in context.Departments select new { dept.ID, dept.DepartmentName }).ToList();
                ddlDepartment.DataValueField = "ID";
                ddlDepartment.DataTextField = "DepartmentName";

                ddlDepartment.DataSource = deptlist;
                ddlDepartment.DataBind();



                using (var empContext = new EmployeesEntities())
                {
                    
                    //var contextList = from c in empContext.Emps select c;
                    //grdEmployees.DataSource = contextList.ToList();
                    //grdEmployees.DataBind();

                    var data = from a in empContext.Emps
                               select a;


                    //Select single fields of the record
                    var data2 = from a in empContext.Emps
                               select a.EmpName;

                    //Lambda Expression/Method syntax
                   IEnumerable<string> data_L1 = empContext.Emps.Select(b => b.EmpName);


                    //Select list of columns from collection
                    var data3 = from a in empContext.Emps
                                select new { a.ID, a.EmpName, a.EmpPhoneNumber, a.EmpAddress };


                    //Lambda Expression/Method syntax
                   // IEnumerable<string> data_L2 = empContext.Emps.Select(new {b.EmpName,b.EmpPhoneNumber,b.DeptId};


                    //Select list of columns from collection with condition
                    int deptid = Convert.ToInt16(ddlDepartment.SelectedItem.Value);
                    var data4 = from b in context.Emps
                                where b.DeptId == deptid
                               //where b.EmpAddress contains("Delhi")
                               select new { b.EmpName, b.EmpPhoneNumber, b.EmpAddress };


                    //Order by query syntax, this too return IEnumerable type otherwise query type return IQuerable
                    IEnumerable<Emp> data6 = from a in empContext.Emps
                                orderby a.EmpName descending,a.EmpAddress
                               select a;


                    //Method syntax / sorting on another table FK
                    IEnumerable<Emp> data7 = context.Emps.OrderByDescending(b => b.Department.DepartmentName)
                                            .ThenBy(b => b.EmpAddress);

                    //Order by query syntax
                    var data8 = from a in empContext.Emps
                                where a.EmpAddress.Contains("Delhi") || a.EmpAddress.Contains("India")
                                orderby a.EmpName descending, a.EmpAddress
                                select a;

                    //Method syntax for contains and multiple data
                    IEnumerable<Emp> data9 = empContext.Emps.Where(b => (b.EmpAddress.Contains("delhi")
                            && b.DeptId < 5));

                    //To improve readability - creation of local variable in LINQ
                    IEnumerable<Emp> data10 = from b in context.Emps
                                              let EName = b.EmpName
                                              let DepartmentNo = b.DeptId
                                              select b;


                    //Set statement except
                    IEnumerable<Emp> exceptData = data.Except(data8);
                    exceptData = exceptData.Reverse();

                    //To concate 2 similar list
                    IEnumerable<Emp> unionData = data8.Concat(data9);
                    
                    //Skip works with ordered data
                   IEnumerable<Emp> skipData = data.OrderBy(b=>b.DeptId).Skip(5).Take(2);

                   //Return employee list between id 5 and 10 and worked on Method syntax
                   IEnumerable<Emp> page1 = data9.OrderBy(empl => empl.EmpName)
                                     .SkipWhile(empl => empl.ID < 5)
                                     .TakeWhile(empl => empl.ID < 10);



                    //To get the first or default record and to fetch element from the specified location
                   Emp FirstRecord = context.Emps.FirstOrDefault(b => b.ID < 10);
                   
                   //ElementAt does not work directly, you need to first get the resultset then query 
                   IEnumerable<Emp> page3 = context.Emps.Where(b => b.ID > 1);
                   Emp rec= page3.ElementAt(1);


                   Emp[] arrEmp = context.Emps.ToArray();
                   List<Emp> lstEmp = context.Emps.ToList();



                   //ToDictionary method to convert data to dictionary
                   Dictionary<int, Emp> EmpByName = context.Emps.ToDictionary(em => em.ID);
                   
                    
                    
                    //ToDictionary method to convert custom data
                    Dictionary<int, string> EmpDeptWise = context.Emps.ToDictionary(em => em.ID,
                                                   em => em.Department.DepartmentName);



                   if (data.Any(em => em.DeptId >= 5))
                       Console.WriteLine("Employee Working in dept 5");

                   if (data.All(em => em.DeptId == 5))
                       Console.WriteLine("All books are cheaper than 500$");




                    //Aggregate functions
                   //int[] numbers = { 5, 4, 1, 3, 9, 8, 6, 7, 2, 0 };

                   //Console.WriteLine("Count of numbers greater than 5 is {0} ", numbers.Count(x => x > 5));
                   //Console.WriteLine("Sum of even numbers is {0} ", numbers.Sum(x => Convert.ToInt32(x % 2 == 0)));
                   //Console.WriteLine("Minimum odd number is {0} ", numbers.Min(x => (x % 2 == 1)));
                   //Console.WriteLine("Maximum is {0} ", numbers.Max());
                   //Console.WriteLine("Average is {0} ", numbers.Average());



                    //Error
                   //var baCollection = from emp in context.Emps
                   //                   from dept in context.Departments
                   //                   from sales in context.Sales
                   //                   where emp.DeptId == dept.ID
                   //                      //&& sales.Sale_Amount < 500
                   //                      && emp.ID==sales.EmpID
                   //                   select new { Emp = emp, Sales = sales };




                   var empl_db = from p in context.Departments
                                 join b in context.Emps on p.ID equals b.DeptId
                                 into EmpDepartment
                                 select new {Department=p}; // new { Emp = p, Dept = EmpDepartment };



                   List<int> list = new List<int>() {0,1,2,3,4,5,6,7};
                   list.Add(8);



                   grdEmployees.DataSource = empl_db.ToList();
                    grdEmployees.DataBind();
                }

            }
        }




        protected void btnDeptWiseList_Click(object sender, EventArgs e)
        {
            using (var context=new EmployeesEntities())
            {
                //var data = from c in context.Emps
                //           where c.DeptId == (ddlDepartment.SelectedItem.Value)
                //           select c;


                //IEnumerable<Emp> data = context.Emps.Where(d => d.DeptId == "1").Select(new {d.ID, d.EmpName,d.EmpAddress,d.EmpPhoneNumber,d.DeptId});

                int deptid= Convert.ToInt16(ddlDepartment.SelectedItem.Value);

                var data= from b in context.Emps
                          where b.DeptId == deptid
                          select new {b.EmpName, b.EmpPhoneNumber,b.EmpAddress};


                grdEmployeesDeptWise.DataSource= data.ToList();
                grdEmployeesDeptWise.DataBind();

                //List<string> = new List<string>();

            }

        }
    }
}