﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DemoEFWebForm1
{
    public partial class EmployeeAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


        }


        protected void btnTest_Click(object sender, EventArgs e)
        {

            lblDemo.InnerText = "Hello";

        }


        protected void btnsave_Click(object sender, EventArgs e)
        {
            EmployeesEntities emp = new EmployeesEntities();
            Emp empobj = new Emp();
            empobj.EmpName = txtname.Text;
            empobj.EmpAddress = txtaddress.Text;
            empobj.EmpPhoneNumber = txtmobileno.Text;
            empobj.DeptId = Convert.ToInt16(ddlDeptName.SelectedItem.Value);

            emp.Emps.Add(empobj);
            emp.SaveChanges();
            ClientScript.RegisterClientScriptBlock(GetType(), "Javascript", "<script>alert('Record Added')</script>");
        }


    }
}