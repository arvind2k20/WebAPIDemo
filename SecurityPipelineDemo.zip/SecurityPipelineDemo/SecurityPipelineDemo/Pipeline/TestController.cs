﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using SecurityPipelineDemo;

namespace SecurityPipelineDemo.Pipeline
{
    public class TestController : ApiController
    {
        [TestAuthenticationFilterAttribute]
        [TestAuthorizationFilter]
        public IHttpActionResult Get()
        {

            Helper.Write("Controller", User);
            //Helper.Write("Controller", Request.GetRequestContext().Principal);
            return Ok();
        }
    }
}
